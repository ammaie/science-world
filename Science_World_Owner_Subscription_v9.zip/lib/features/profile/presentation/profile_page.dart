import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../auth/data/auth_service.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _auth = AuthService();
  final _nameController = TextEditingController();
  bool _saving = false;
  bool _editing = false;
  String? _message;

  @override
  void initState() {
    super.initState();
    _nameController.text = (_auth.currentUser?.userMetadata?['full_name'] ?? '').toString();
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _saveName() async {
    final name = _nameController.text.trim();
    if (name.length < 2) {
      setState(() => _message = 'اكتب اسمًا من حرفين على الأقل.');
      return;
    }
    setState(() { _saving = true; _message = null; });
    try {
      final client = _auth.isConfigured ? _auth.currentUser : null;
      if (client == null) throw Exception('يجب تسجيل الدخول أولًا.');
      // User metadata is updated through the authenticated Supabase session.
      await _updateDisplayName(name);
      if (mounted) setState(() { _editing = false; _message = 'تم حفظ الاسم بنجاح.'; });
    } catch (_) {
      if (mounted) setState(() => _message = 'تعذر حفظ الاسم. تحقق من الاتصال ثم حاول مجددًا.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _updateDisplayName(String name) async {
    // Keep auth operations in AuthService; profile metadata is updated there.
    await _auth.updateDisplayName(name);
  }

  Future<void> _openWhatsApp() async {
    const phone = '905389567265';
    final uri = Uri.parse('https://wa.me/$phone?text=${Uri.encodeComponent('مرحبًا، أحتاج مساعدة في تطبيق عالم العلوم.')}');
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
        if (mounted) setState(() => _message = 'تعذر فتح واتساب. يمكنك نسخ الرقم والتواصل يدويًا.');
      }
    } catch (_) {
      if (mounted) setState(() => _message = 'تعذر فتح واتساب.');
    }
  }

  Future<void> _copyPhone() async {
    await Clipboard.setData(const ClipboardData(text: '+90 538 956 7265'));
    if (mounted) setState(() => _message = 'تم نسخ رقم التواصل.');
  }

  @override
  Widget build(BuildContext context) {
    final user = _auth.currentUser;
    final email = user?.email ?? 'غير مسجّل';
    final theme = Theme.of(context);
    final displayName = _nameController.text.trim().isNotEmpty
        ? _nameController.text.trim()
        : 'طالب عالم العلوم';
    return Scaffold(
      appBar: AppBar(title: const Text('ملفي الشخصي'), centerTitle: true),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(20, 26, 20, 24),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [theme.colorScheme.primary, theme.colorScheme.primary.withOpacity(.76)], begin: Alignment.topRight, end: Alignment.bottomLeft),
              borderRadius: BorderRadius.circular(26),
              boxShadow: [BoxShadow(color: theme.colorScheme.primary.withOpacity(.20), blurRadius: 22, offset: const Offset(0, 10))],
            ),
            child: Column(children: [
              Container(width: 88, height: 88, decoration: BoxDecoration(color: Colors.white.withOpacity(.17), shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.75), width: 2)), child: const Icon(Icons.school_rounded, color: Colors.white, size: 44)),
              const SizedBox(height: 14),
              Text(displayName, textAlign: TextAlign.center, style: theme.textTheme.titleLarge?.copyWith(color: Colors.white, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text(email, textAlign: TextAlign.center, style: theme.textTheme.bodyMedium?.copyWith(color: Colors.white.withOpacity(.9))),
              const SizedBox(height: 12),
              Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), decoration: BoxDecoration(color: Colors.white.withOpacity(.15), borderRadius: BorderRadius.circular(30)), child: const Text('عالم العلوم • رحلتك نحو التفوق', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600))),
            ]),
          ),
          const SizedBox(height: 22),
          Text('معلومات الحساب', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Card(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: theme.dividerColor.withOpacity(.35))), child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
            if (_editing) TextField(controller: _nameController, maxLength: 60, textInputAction: TextInputAction.done, decoration: const InputDecoration(labelText: 'الاسم الظاهر', prefixIcon: Icon(Icons.person_outline), border: OutlineInputBorder()), onSubmitted: (_) => _saveName())
            else _infoRow(Icons.person_outline, 'الاسم الظاهر', displayName),
            const Divider(height: 24),
            _infoRow(Icons.alternate_email_rounded, 'البريد الإلكتروني', email),
            const Divider(height: 24),
            _infoRow(Icons.verified_user_outlined, 'حالة الحساب', user == null ? 'غير مسجّل الدخول' : (user.emailConfirmedAt != null ? 'البريد مؤكّد' : 'بانتظار تأكيد البريد')),
            const SizedBox(height: 14),
            SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _saving ? null : () { if (_editing) { _saveName(); } else { setState(() { _editing = true; _message = null; }); } }, icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : Icon(_editing ? Icons.save_rounded : Icons.edit_rounded), label: Text(_editing ? 'حفظ التعديلات' : 'تعديل الملف الشخصي'))),
          ]))),
          const SizedBox(height: 22),
          Text('تحتاج إلى مساعدة؟', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Card(elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: theme.dividerColor.withOpacity(.35))), child: Column(children: [
            ListTile(leading: const CircleAvatar(child: Icon(Icons.chat_rounded)), title: const Text('تواصل عبر واتساب'), subtitle: const Text('+90 538 956 7265'), trailing: const Icon(Icons.open_in_new_rounded), onTap: _openWhatsApp),
            const Divider(height: 1, indent: 16, endIndent: 16),
            ListTile(leading: const CircleAvatar(child: Icon(Icons.copy_rounded)), title: const Text('نسخ رقم التواصل'), subtitle: const Text('انسخ الرقم لاستخدامه في واتساب'), onTap: _copyPhone),
          ])),
          if (_message != null) ...[const SizedBox(height: 12), Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: theme.colorScheme.secondaryContainer, borderRadius: BorderRadius.circular(12)), child: Text(_message!, textAlign: TextAlign.center))],
          const SizedBox(height: 20),
          OutlinedButton.icon(style: OutlinedButton.styleFrom(foregroundColor: theme.colorScheme.error, padding: const EdgeInsets.symmetric(vertical: 14)), onPressed: () async { await _auth.signOut(); if (context.mounted) context.go('/'); }, icon: const Icon(Icons.logout_rounded), label: const Text('تسجيل الخروج')),
          const SizedBox(height: 12),
          const Center(child: Text('Science World • عالم العلوم', style: TextStyle(fontSize: 12, color: Colors.grey))),
        ],
      ),
    );
  }

  Widget _infoRow(IconData icon, String title, String value) => Row(children: [Icon(icon, size: 22, color: Theme.of(context).colorScheme.primary), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)), const SizedBox(height: 3), Text(value, style: const TextStyle(fontWeight: FontWeight.w600), maxLines: 2, overflow: TextOverflow.ellipsis)])]);
}
