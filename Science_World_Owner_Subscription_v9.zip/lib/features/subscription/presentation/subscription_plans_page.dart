import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../data/subscription_service.dart';
import '../data/subscription_model.dart';

class SubscriptionPlansPage extends StatelessWidget {
  const SubscriptionPlansPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الاشتراك')),
      body: FutureBuilder<SubscriptionModel?>(
        future: SubscriptionService().fetchMySubscription(),
        builder: (context, snapshot) {
          final current = snapshot.data;
          final bool isPremium = current?.isPremium ?? false;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text('اختر الخطة المثالية لك', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 16),
              _PlanCard(
                title: 'مجاني',
                price: '0 ل.س',
                features: const [
                  'الوصول إلى المحتوى المجاني فقط',
                  'أسئلة محدودة من بنك الأسئلة',
                  'الوصول إلى الكتب المسموح بتنزيلها مجانًا',
                  'لا يشمل المحتوى المدفوع',
                ],
                isCurrent: !isPremium,
                isPremium: false,
                onTap: null,
              ),
              const SizedBox(height: 12),
              _PlanCard(
                title: 'مميز',
                price: '15 ل.س / شهر',
                features: const [
                  'الوصول إلى جميع المحتوى',
                  'بنك أسئلة كامل',
                  'تنزيل جميع الكتب',
                  'امتحانات تجريبية كاملة',
                  'لا إعلانات',
                ],
                isCurrent: isPremium,
                isPremium: true,
                onTap: isPremium ? null : () => context.push('/payment-help'),
              ),
              if (isPremium) ...[
                const SizedBox(height: 16),
                Text(
                  'الاشتراك نشط حتى ${current!.expiresAt?.toLocal().toString().split(' ')[0] ?? '-'}',
                  style: TextStyle(color: Colors.green, fontWeight: FontWeight.bold),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  final String title;
  final String price;
  final List<String> features;
  final bool isCurrent;
  final bool isPremium;
  final VoidCallback? onTap;

  const _PlanCard({
    required this.title,
    required this.price,
    required this.features,
    required this.isCurrent,
    required this.isPremium,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: isPremium ? 4 : 1,
      shape: RoundedRectangleBorder(
        side: BorderSide(
          color: isPremium ? Colors.blue : Colors.transparent,
          width: 2,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(price),
        trailing: isCurrent
            ? Chip(
                label: const Text('حاليًا'),
                backgroundColor: isPremium ? Colors.blue[50] : Colors.green[50],
              )
            : null,
        onTap: onTap,
      ),
    );
  }
}