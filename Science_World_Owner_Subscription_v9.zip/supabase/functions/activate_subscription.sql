-- Supabase Edge Function: activate_subscription
-- Called from Flutter via RPC: `activate_subscription(p_user_id, p_code)`
-- Verifies code, checks limits, activates subscription for one calendar month.

create or replace function activate_subscription(p_user_id uuid, p_code text)
returns boolean as $$
declare
  v_code_id uuid;
  v_is_used boolean;
  v_attempts integer;
  v_max_attempts constant integer := 3;
  v_expires_at timestamptz;
  v_starts_at timestamptz;
  v_new_expires timestamptz;
begin
  -- Find the code by hash
  select id, is_used, expires_at into v_code_id, v_is_used, v_expires_at
  from activation_codes
  where code_hash = crypt(p_code, gen_salt('bf'))
  limit 1;

  if v_code_id is null then
    insert into activation_logs (user_id, code_id, success, reason)
    values (p_user_id, null, false, 'invalid_code');
    return false;
  end if;

  if v_is_used then
    insert into activation_logs (user_id, code_id, success, reason)
    values (p_user_id, v_code_id, false, 'already_used');
    return false;
  end if;

  if v_expires_at is not null and v_expires_at < now() then
    insert into activation_logs (user_id, code_id, success, reason)
    values (p_user_id, v_code_id, false, 'expired');
    return false;
  end if;

  -- Check attempts
  select count(*) into v_attempts
  from activation_logs
  where user_id = p_user_id and success = false and created_at > now() - interval '1 hour';

  if v_attempts >= v_max_attempts then
    insert into activation_logs (user_id, code_id, success, reason)
    values (p_user_id, v_code_id, false, 'too_many_attempts');
    return false;
  end if;

  -- Activate subscription
  v_starts_at := now();
  v_new_expires := (v_starts_at + interval '1 month')::timestamptz;

  update activation_codes
  set is_used = true, used_by = p_user_id, used_at = now()
  where id = v_code_id;

  insert into subscriptions (user_id, status, starts_at, expires_at, activated_by_code_id, source)
  values (p_user_id, 'premium', v_starts_at, v_new_expires, v_code_id, 'code');

  insert into activation_logs (user_id, code_id, success, reason)
  values (p_user_id, v_code_id, true, 'success');

  return true;
end;
$$ language plpgsql security definer;